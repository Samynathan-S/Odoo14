Time Type is useful during daily or weekly planning meetings to quickly
identify the nature of task based on the timesheet entries.

Time Type is also useful for weekly or monthly reporting provided to clients
based on exports from the PM System to provide high level classifications
for timesheet logs.
