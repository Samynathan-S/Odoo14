#. Go to *Timesheets* and creates a new record.
#. Go to *Invoicing > Configuration > Management > Analytic Items*.
#. The previously created record will have the defined employee's analytical tags.
