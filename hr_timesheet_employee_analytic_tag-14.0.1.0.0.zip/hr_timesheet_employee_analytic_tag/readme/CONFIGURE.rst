To configure this module, you need to:

#. Go to *Settings > Users & Companies > Users*.
#. Give your user these technical permissions to see all required elements:
    * Analytic Accounting
    * Analytic Accounting Tags
    * Show Full Accounting Features

#. Go to the Employees app and edit your employee (should match your user).
#. Choose or create 'Analytic Tags' in 'Timesheets' under 'HR Settings' tab.
