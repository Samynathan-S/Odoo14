This module allows to define analytical labels in employees to be set when creating analytical items.
